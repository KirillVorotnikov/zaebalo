"""PDF conversion helpers."""
