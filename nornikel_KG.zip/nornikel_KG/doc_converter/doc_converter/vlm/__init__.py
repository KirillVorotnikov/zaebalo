"""Vision-language model backends."""
