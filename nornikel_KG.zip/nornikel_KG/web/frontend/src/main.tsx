import ReactDOM from 'react-dom/client';
import './i18n';
import './styles/theme.css';
import './styles/global.css';
import App from './App';

ReactDOM.createRoot(document.getElementById('root')!).render(<App />);
